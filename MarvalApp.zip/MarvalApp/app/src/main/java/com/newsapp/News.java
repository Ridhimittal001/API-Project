package com.newsapp;

import java.util.ArrayList;

public class News {
    int totalResults;
    String status;
    ArrayList<News1 >articles =new ArrayList();
}
