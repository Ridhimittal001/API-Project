package com.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyNewsAdapter  extends BaseAdapter {
Context cont;
ArrayList<News1> art;

    public MyNewsAdapter(Context applicationContext, ArrayList< News1 > articles) {
        cont=applicationContext;
        art=articles;
    }

    @Override
    public int getCount() {
        return art.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflat=LayoutInflater.from(cont);
        view=inflat.inflate(R.layout.activity_sampleactivity,null);
        ImageView img=view.findViewById(R.id.imgnews);
        Picasso.get().load(art.get(i).urlToImage).into(img);
//        TextView txt=view.findViewById(R.id.titlehere);
//        txt.setText(art.get(i).title);
//        TextView txt1=view.findViewById(R.id.descrption);
//        txt1.setText(art.get(i).description);
        return view;
    }
}
