package com.newsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      readdatafromServer();

        News news=new News();

    }
    private void readdatafromServer(){
        Retrofit retro=new Retrofit.Builder().baseUrl("https://newsapi.org").addConverterFactory(GsonConverterFactory.create()).build();
        Call<News> obj=retro.create(myInterface.class).getdata();
        obj.enqueue(new Callback< News >() {
            @Override
            public void onResponse(Call< News > call, Response< News > response) {
                System.out.println("total movies"+response.body().articles);
                System.out.println("total movies"+response.body().status);

                MyNewsAdapter adp=new MyNewsAdapter(getApplicationContext(),response.body().articles);
                GridView list=findViewById(R.id.newsList);
                list.setAdapter(adp);
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView< ? > adapterView, View view, int i, long l) {
//                        Toast.makeText(getApplicationContext(), response.body().status, Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(),sample2.class);
                        intent.putExtra("name", response.body().articles.get(i).title);
                        intent.putExtra("image", response.body().articles.get(i).urlToImage);
                        intent.putExtra("description", response.body().articles.get(i).description);
                        startActivity(intent);
                    }
            });
            }
            @Override
            public void onFailure(Call< News > call, Throwable t) {

            }

        });
    }
    interface myInterface
    {
        @GET("/v2/top-headlines?country=us&category=business&apiKey=48e5255df493434ba61720d5a7867317")
        Call<News >getdata();
    }


}