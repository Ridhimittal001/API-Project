package com.newsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class sample2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample2);
        //view finding
        TextView nametxt= findViewById(R.id.titlehere);
        ImageView imageshow=findViewById(R.id.imgnews);
        TextView descriptionTxt= findViewById(R.id.descrption);

        String receivedName = getIntent().getStringExtra("name");
        String receivedDes = getIntent().getStringExtra("description");
        String receivedImage = getIntent().getStringExtra("image");
//        Toast.makeText(getApplicationContext(),receivedDes, Toast.LENGTH_LONG).show();
        Picasso.get().load(receivedImage).into(imageshow);
        nametxt.setText(receivedName);
        descriptionTxt.setText(receivedDes);
        //enable back Button

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}