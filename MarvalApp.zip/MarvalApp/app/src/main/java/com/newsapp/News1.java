package com.newsapp;

public class News1 {
    public String author;
    public String title;
    public String description;
    public String urlToImage;
    public String publishedAt;
}
